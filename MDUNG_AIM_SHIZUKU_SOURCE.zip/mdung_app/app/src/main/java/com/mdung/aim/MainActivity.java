package com.mdung.aim;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.content.pm.PackageManager;
import rikka.shizuku.Shizuku;
import java.io.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView log;
    private static final int REQ = 101;
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        write(result == PackageManager.PERMISSION_GRANTED ? "Shizuku: đã cấp quyền" : "Shizuku: chưa được cấp quyền");
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28,28,28,28); root.setBackgroundColor(Color.rgb(12,17,28));
        ScrollView sc = new ScrollView(this); sc.addView(root); setContentView(sc);
        label("MDUNG • AIM VMAX",24,0xff58e0cc);
        label("Điều khiển tối ưu hệ thống • Không sửa dữ liệu game",13,Color.LTGRAY);
        button("KẾT NỐI SHIZUKU", () -> {
            if (!Shizuku.pingBinder()) { write("Hãy mở Shizuku và khởi động dịch vụ trước."); return; }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(REQ);
            else write("Shizuku đã kết nối và có quyền.");
        });
        toggle("Giảm hiệu ứng giao diện", "animation", true);
        toggle("Tắt rung phản hồi", "haptic", true);
        toggle("Tăng tốc con trỏ ngoài", "pointer", true);
        label("HỖ TRỢ KÉO TÂM",19,0xff58e0cc);
        label("Các chế độ dưới đây là cấu hình luyện tập, không tác động đến cơ chế ngắm trong Free Fire MAX.",13,Color.LTGRAY);
        toggle("Nhẹ tâm (hồ sơ luyện tập)","light",false);
        toggle("Đầm tâm (hồ sơ luyện tập)","steady",false);
        toggle("Fix lố đầu (hồ sơ luyện tập)","overshoot",false);
        toggle("Bám vùng đầu (hồ sơ luyện tập)","head",false);
        label("NHẬT KÝ LỆNH",18,0xff58e0cc);
        log = label("Sẵn sàng.\n",13,Color.WHITE);
        Shizuku.addRequestPermissionResultListener(permissionListener);
    }
    private TextView label(String s,int size,int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,14,0,14); root.addView(t); return t;
    }
    private void button(String name,Runnable r) { Button b = new Button(this); b.setText(name); root.addView(b); b.setOnClickListener(v -> r.run()); }
    private void toggle(String name,String key,boolean system) {
        Switch sw = new Switch(this); sw.setText(name); sw.setTextColor(Color.WHITE); sw.setPadding(0,20,0,20); root.addView(sw);
        sw.setOnCheckedChangeListener((b,on) -> {
            if (!system) { getPreferences(0).edit().putBoolean(key,on).apply(); write(name+": "+(on?"BẬT":"TẮT")+" (chỉ lưu cấu hình)"); return; }
            String cmd;
            if (key.equals("animation")) cmd = "settings put global window_animation_scale "+(on?"0.5":"1")+"; settings put global transition_animation_scale "+(on?"0.5":"1")+"; settings put global animator_duration_scale "+(on?"0.5":"1");
            else if (key.equals("haptic")) cmd = "settings put system haptic_feedback_enabled "+(on?"0":"1");
            else cmd = "settings put system pointer_speed "+(on?"5":"0");
            execute(cmd);
        });
        if (!system) sw.setChecked(getPreferences(0).getBoolean(key,false));
    }
    private void execute(String command) {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED) {write("Cần kết nối và cấp quyền Shizuku.");return;}
        new Thread(() -> {
            try {
                // Shizuku RemoteProcess supports the shell command through its binder.
                android.os.ParcelFileDescriptor pfd = null;
                // Avoid invoking hidden Android APIs: use Shizuku's newProcess compatibility interface.
                java.lang.reflect.Method method = Shizuku.class.getMethod("newProcess",String[].class,String[].class,String.class);
                Object proc = method.invoke(null,new Object[]{new String[]{"sh","-c",command},null,null});
                int exit = (Integer)proc.getClass().getMethod("waitFor").invoke(proc);
                runOnUiThread(() -> write("$ "+command+"\nexit="+exit));
            } catch (Exception e) {runOnUiThread(() -> write("Không chạy được lệnh: "+e.getClass().getSimpleName()));}
        }).start();
    }
    private void write(String s) {if(log!=null) log.append(s+"\n");}
    @Override protected void onDestroy(){Shizuku.removeRequestPermissionResultListener(permissionListener);super.onDestroy();}
}
