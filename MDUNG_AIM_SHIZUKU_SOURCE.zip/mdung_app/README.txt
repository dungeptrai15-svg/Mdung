MDUNG AIM VMAX — Android source project
Build: Android Gradle Plugin 8.5.2, Gradle 8.7, JDK 17.
Open with Android Studio or build using a GitHub Actions workflow.
Requires the Shizuku app and an active Shizuku service for system setting changes.
The manual aim toggles only store training preferences. They do not detect heads, intercept touches, or modify Free Fire MAX.
Pointer speed applies to external pointer devices, not touchscreen aim.
Some Android builds may reject settings writes.
